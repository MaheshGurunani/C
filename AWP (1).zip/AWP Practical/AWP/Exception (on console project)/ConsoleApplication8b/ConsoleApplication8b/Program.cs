﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace userdefined
{
    class Program
    {
        static void Main()
        {
            Console.Write("\n\n");
            Console.Write("Determine a specific age is eligible for casting the vote:\n");
            Console.Write(".........................................................");
            Console.Write("\n\n");
            Console.WriteLine("Enter Username");
            string username = Console.ReadLine();
            Console.WriteLine("Username is:" + username);
            Console.WriteLine("Enter Locality:");
            string locality = Console.ReadLine();
            Console.WriteLine("Locality is:" + locality);
            Console.WriteLine("Enter voter age:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Voter age is:" + age);
            try
            {
                if(age>18)
                {
                    Console.WriteLine("Congratulations! you are eligible for casting your vote");
                    Console.ReadLine();
                }
                else
                {
                    throw (new InvalidAgeException("Invalid age exception generated : sorry,age must be greater than 18"));
                }
            }
            catch(InvalidAgeException ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.ReadLine();
            }
         }
    }
}
public class InvalidAgeException : Exception
{
    public InvalidAgeException(String message):base(message)
    {
    }
}


















