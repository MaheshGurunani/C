﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int a, b, c, i, n;
        a = 0;
        b = 1;
        Label1.Text = a.ToString()  +" " +b.ToString();
        n = Convert.ToInt32(TextBox1.Text);
        for (i = 1; i <= n; ++i)
        {
            c = a + b;
            Label1.Text = Label1.Text +" "+ c.ToString();
            a = b;
            b = c;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int i, c = 0, j, num;
        num = Convert.ToInt32(TextBox2.Text);
        for (j = 1; j <= num; j++)
        {
            i = num % j;
            if (i == 0)
            {
                c = c + 1;
            }
        }
        if (c == 2)
            Label2.Text = "This given number is prime";
        else
            Label2.Text = "This given number is not prime";
    }
}