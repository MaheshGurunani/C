﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace practical3b
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            Label2.Text = "Date:" +Calendar1.SelectedDate.Date.ToString();

        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            if (e.Day.Date.Day == 20)
                e.Cell.Controls.Add(new LiteralControl("<br/>Holiday"));
      if ((e.Day.Date >= new DateTime(2024, 07, 31)) && (e.Day.Date <= new DateTime(2024, 08, 6)))
            {
                e.Cell.BackColor = System.Drawing.Color.Cyan;
                e.Cell.BorderColor = System.Drawing.Color.Black;
                e.Cell.BorderWidth = new Unit(3);
            }
            if (e.Day.IsOtherMonth)
            {
                e.Cell.Controls.Clear();
            }
           if (e.Day.Date.Day == 5 && e.Day.Date.Month == 9)
            {
                e.Cell.BackColor = System.Drawing.Color.Yellow;
                Label lb1 = new Label();
                lb1.Text = "<br>Teachers Day!";
                e.Cell.Controls.Add(lb1);
                Image g1 = new Image();
                g1.ImageUrl = "~/a.jpg";
                g1.Height = 20;
                g1.Width = 20;
                e.Cell.Controls.Add(g1);
            }
            if (e.Day.Date.Day == 13 && e.Day.Date.Month == 7)
            {
                Calendar1.SelectedDate = new DateTime(2024, 7, 12);
                Calendar1.SelectedDates.SelectRange(Calendar1.SelectedDate, Calendar1.SelectedDate.AddDays(10));
                Label lb1 = new Label();
                lb1.Text = "<br>Ganpati!";
                e.Cell.Controls.Add(lb1);
            }
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
            Label2.Text = " ";
            Label4.Text = " ";
            Label6.Text = " ";
            Calendar1.SelectedDates.Clear();

        }

      
        protected void Button1_Click1(object sender, EventArgs e)
        {
            Calendar1.Caption = "Calendar";
            Calendar1.FirstDayOfWeek = FirstDayOfWeek.Sunday;
            Calendar1.NextPrevFormat = NextPrevFormat.ShortMonth;
            Calendar1.TitleFormat = TitleFormat.Month;
            Label4.Text = " Date" + Calendar1.TodaysDate.ToShortDateString();
            Label6.Text = "Vacation : 8-31-2024";  

        }

       
    }
}
