﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int a, b, c, i, n;
        int
        cube = Convert.ToInt32(TextBox1.Text) * Convert.ToInt32(TextBox1.Text) * Convert.ToInt32(TextBox1.Text);
        a = 0;
        b = 1;
        Label1.Text = a.ToString() + " " + b.ToString();
        n = Convert.ToInt32(TextBox1.Text);
        for (i = 1; i <= n; ++i)
        {
            c = a + b;
            Label1.Text = Label1.Text + " " + c.ToString();
            a = b;
            b = c;
          Label2.Text = " " + cube;
        }
    }

}
