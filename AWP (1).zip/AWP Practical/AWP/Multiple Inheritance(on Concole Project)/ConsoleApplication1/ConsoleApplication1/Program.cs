﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{

    interface Addition
    {
        int Add(int a, int b);
    }

    interface Subtraction
    {
        int Sub(int a, int b);
    }

    class Calculation : Addition, Subtraction
    {
        // Implementing Add method from Addition interface
        public int result1;
        public int Add(int a, int b)
        {
            return result1 = a + b;
        }
        public int result2;
        // Implementing Subtract method from ISubtraction interface
        public int Sub(int a, int b)
        {
            return result2 = a - b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Calculation c = new Calculation();
            c.Add(8, 23);
            c.Sub(25, 8);

            Console.WriteLine("Multiple Interface:");
            Console.WriteLine("Addition is:"+ c.result1);
             Console.WriteLine("Addition is:" +c.result2);

            Console.ReadLine();
        }
    }
}

