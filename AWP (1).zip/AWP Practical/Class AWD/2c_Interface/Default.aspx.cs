﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

interface Area
{
    double show(double s, double t);
}

interface Area1
{
     double show(double s, double t);
}
class Circle : Area, Area1
{
    public double show(double s, double t)
    {
        return (3.14 * s * s);
    }
   
}
public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
       


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Circle c1 = new Circle();
        double x = c1.show(3, 4);
        Label1.Text = x.ToString();
        
    }
}