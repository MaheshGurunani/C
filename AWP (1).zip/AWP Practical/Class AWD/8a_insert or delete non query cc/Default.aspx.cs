﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
 
        string connStr = WebConfigurationManager.ConnectionStrings["StudentConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        string InsertQuery = "insert into TYStudent values (@rollno,@name,@class,@course)";
        SqlCommand cmd = new SqlCommand(InsertQuery, con);
        cmd.Parameters.AddWithValue("@rollno", TextBox1.Text);
        cmd.Parameters.AddWithValue("@name", TextBox2.Text);
        cmd.Parameters.AddWithValue("@class", TextBox3.Text);
        cmd.Parameters.AddWithValue("@course", TextBox4.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "Record Inserted Successfuly.";
        con.Close();

    }
protected void  Button2_Click(object sender, EventArgs e)
   {
        string connStr = WebConfigurationManager.ConnectionStrings["StudentConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        string DeleteQuery = "delete from TYStudent where RollNo=@rollno";
        SqlCommand cmd = new SqlCommand(DeleteQuery, con);
        cmd.Parameters.AddWithValue("@rollno", TextBox1.Text); 
        con.Open();
        cmd.ExecuteNonQuery();
         Label1.Text = "Record Deleted Successfuly.";
        con.Close();
   }
}
   