﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            if (ViewState["count"] != null)
            {
                int ViewStateVal = Convert.ToInt32(ViewState["count"]) + 1;
                Label2.Text = "Hidden field :" + ViewStateVal.ToString();
                ViewState["count"] = ViewStateVal.ToString();
            }
            else
            {
                ViewState["count"] = "1";
            }
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != null)
        {
            int val = Convert.ToInt32(HiddenField1.Value) + 1;
            HiddenField1.Value = val.ToString();
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label3.Text = ViewState["count"].ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default2.aspx?UserId=" + TextBox1.Text + "&UserName=" + TextBox2.Text);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        HttpCookie h = new HttpCookie("name");
        h.Value = TextBox3.Text;
        Response.Cookies.Add(h);
        Response.Redirect("Default3.aspx");


    }
    protected void HiddenField1_ValueChanged(object sender, EventArgs e)
    {

    }
}