﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie c1 = new HttpCookie("creator");
        c1.Value = "Suraj Vishwakarma";
        Response.Cookies.Add(c1);
        String author = Response.Cookies["creator"].Value;
        Label1.Text = author;
        Response.Cookies["comp"].Expires = DateTime.Now.AddDays(-1);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         Label2.Text = "";
        if (Apple.Checked)
            Response.Cookies["comp"]["Apple"] = "apple";
        if (Dell.Checked)
            Response.Cookies["comp"]["Dell"] = "Dell";
        if (Lenovo.Checked)
            Response.Cookies["comp"]["Lenovo"] = "Lenovo";
        if (Acer.Checked)
            Response.Cookies["comp"]["Acer"] = "acer";
        if (Sony.Checked)
            Response.Cookies["comp"]["Sony"] = "Sony";
        if (Wipro.Checked)
            Response.Cookies["comp"]["Wipro"] = "Wipro";
        if (Request.Cookies["comp"].Values.ToString() != null)
        {
            if (Request.Cookies["comp"]["apple"] != null)
                Label2.Text += Request.Cookies["comp"]["apple"] + "";
            if (Request.Cookies["comp"]["dell"] != null)
                Label2.Text += Request.Cookies["comp"]["dell"] + "";
            if (Request.Cookies["comp"]["lenovo"] != null)
                Label2.Text += Request.Cookies["comp"]["lenovo"] + "";
            if (Request.Cookies["comp"]["acer"] != null)
                Label2.Text += Request.Cookies["comp"]["acer"] + "";
            if (Request.Cookies["comp"]["sony"] != null)
                Label2.Text += Request.Cookies["comp"]["sony"] + "";
            if (Request.Cookies["comp"]["wipro"] != null)
                Label2.Text += Request.Cookies["comp"]["wipro"] + "";
        }
        else Label2.Text = "Please select your choice";
        Response.Cookies["comp"].Expires = DateTime.Now.AddDays(-1);
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
    }
    protected void Dell_CheckedChanged(object sender, EventArgs e)
    {
    }
    protected void Lenovo_CheckedChanged(object sender, EventArgs e)
    {
    }
    protected void Acer_CheckedChanged(object sender, EventArgs e)
    {
    }
    protected void CheckBox5_CheckedChanged(object sender, EventArgs e)
    {
    }
    protected void Wipro_CheckedChanged(object sender, EventArgs e)
    {
    }
}
