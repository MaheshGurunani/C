﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int numOfRows = Convert.ToInt32(TextBox1.Text);
        int number = 1;
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        for (int i = 1; i <= numOfRows; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                sb.Append(number + " ");
                number++;
            }
            sb.Append("<br/>");
        }
        Label1.Text = sb.ToString();
     }
}